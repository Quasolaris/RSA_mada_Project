interface Key {
	
	//====================Methods====================
	public String toString(); //returns key in the format specified in the exercise description
}